<?php
/*
Plugin Name: Applause
Description: Add an applause/like/upvote button to your content.
Version: 0.1
Requires at least: 5.0
Author: Bryan Hadaway
Author URI: https://calmestghost.com/
License: Public Domain
License URI: https://wikipedia.org/wiki/Public_domain
Text Domain: applause
*/

if ( !defined( 'ABSPATH' ) ) {
	http_response_code( 404 );
	die();
}

register_activation_hook( __FILE__, "activate_myplugin" );
// Activate Plugin
function activate_myplugin() {

	// Execute tasks on Plugin activation

	// Insert DB Tables
	init_db_myplugin();
}

add_action( 'wp_enqueue_scripts', 'applause_enqueue' );
function applause_enqueue() {
	wp_enqueue_style( 'applause-style', plugin_dir_url( __FILE__ ) . 'applause.css' );
	wp_register_script( 'applause-script', plugin_dir_url( __FILE__ ) . 'applause.js' );
	wp_enqueue_script( 'applause-script' );
}

add_filter( 'the_content', 'applause_default_placement' );
function applause_default_placement( $content ) {
	if ( is_single() && !is_preview() ) {
		$beforecontent = do_shortcode( '[applause]' );
		$aftercontent = do_shortcode( '[applause]' );
		$fullcontent = $beforecontent . $content . $aftercontent;
	} else {
		$fullcontent = $content;
	}
	return $fullcontent;
}

add_shortcode( 'applause', 'applause_shortcode' );
function applause_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'url'   => esc_url( get_the_permalink() ),
		'color' => 'gray',
	), $atts );
	ob_start();
	echo '<div class="applause"><applause-button url="' . esc_url( $atts['url'] ) . '" color="' . esc_attr( $atts['color'] ) . '" /></div>';
	echo '<style>applause-button{width:32px;height:32px}applause-button .count-container .count{font-size:14px;color:' . esc_attr( $atts['color'] ) . ';margin:-8px}</style>';
	$output = ob_get_clean();
	return $output;
}

function init_db_myplugin() {

	// WP Globals
	global $table_prefix, $wpdb;

	// Customer Table
	$customerTable = $table_prefix . 'claps';

	// Create Customer Table if not exist
	if( $wpdb->get_var( "show tables like '$customerTable'" ) != $customerTable ) {

		// Query - Create Table
		$sql = "CREATE TABLE `$customerTable` (";
		$sql .= " `id` int(11) NOT NULL auto_increment, ";
		$sql .= " `user_id` varchar(500) NOT NULL, ";
		$sql .= " `post_url` varchar(500) NOT NULL, ";
		$sql .= " `user_ip` varchar(500), ";
		$sql .= " `claps` varchar(500), ";
		$sql .= " PRIMARY KEY `customer_id` (`id`) ";
		$sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";

		// Include Upgrade Script
		require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
	
		// Create Table
		dbDelta( $sql );
	}
}

function at_rest_testing_endpoint()
	{
		global $wpdb;
		$tablename=$wpdb->prefix.'claps';
		$query = "SELECT COUNT(*) as cnt FROM $tablename WHERE post_url = '" . $_GET['url'] . "' AND user_ip = '".md5($_SERVER['REMOTE_ADDR'])."'";
	    $result = $wpdb->get_results($query);
		$count = (int)$result[0]->cnt;
		if ($count == 0){
			$data=array(
				'post_url' => $_GET['url'], 
				'user_ip' => md5($_SERVER['REMOTE_ADDR']),
				'claps' => 1);
				$wpdb->insert( $tablename, $data);		
				
		}
		$query = "SELECT COUNT(*) as cnt FROM $tablename  WHERE post_url = '" . $_GET['url']."'";
	    $result = $wpdb->get_results($query);
		$count = (int)$result[0]->cnt;
        return $count;
		#return md5($_SERVER['REMOTE_ADDR']);

				//return new WP_REST_Response('Howdy!!');
	}
	
	/**
	 * at_rest_init
	 */
	function at_rest_init()
	{
		// route url: domain.com/wp-json/$namespace/$route
		$namespace = 'applause/v1';
		$route     = 'update-claps';
	
		register_rest_route($namespace, $route, array(
			'methods'   => 'POST',
			'callback'  => 'at_rest_testing_endpoint'
		));
	}
	
	add_action('rest_api_init', 'at_rest_init');

	function at_rest_clap_count_endpoint()
	{
		global $wpdb;
		$tablename=$wpdb->prefix.'claps';
		
		$query = "SELECT COUNT(*) as cnt FROM $tablename  WHERE post_url = '" . $_GET['url']."'";
	    $result = $wpdb->get_results($query);
		$count = (int)$result[0]->cnt;
        return $count;
		#return md5($_SERVER['REMOTE_ADDR']);

				//return new WP_REST_Response('Howdy!!');
	}
	
	/**
	 * at_rest_init
	 */
	function at_rest_clap_init()
	{
		// route url: domain.com/wp-json/$namespace/$route
		$namespace = 'applause/v1';
		$route     = 'get-claps';
	
		register_rest_route($namespace, $route, array(
			'methods'   => 'POST',
			'callback'  => 'at_rest_clap_count_endpoint'
		));
	}
	
	add_action('rest_api_init', 'at_rest_clap_init');